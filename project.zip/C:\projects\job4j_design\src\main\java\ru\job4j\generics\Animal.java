package ru.job4j.generics;

public class Animal {
    private String name;

    @Override
    public String toString() {
        return "Animal{"
                + "name='"
                + name
                + '\''
                + '}';
    }
}
